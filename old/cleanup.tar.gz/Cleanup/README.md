Role Name
=========

A collection of scripts to cleanup the NextGen system ready for a new migration test

Requirements
------------


Roles
--------------

- Scripts	- Copy scripts to server
- CleanUp	- Run cleanup scripts


Dependencies
------------


Example Playbook
----------------

License
-------

BSD

Authors
------------------

Idemia France
Malcolm Chalmers
