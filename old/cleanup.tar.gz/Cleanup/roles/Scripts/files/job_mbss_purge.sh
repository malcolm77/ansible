#!/bin/sh
# arg $1 : target mbss server
# arg $2 : clean option (yes / no)

echo "***** MBSS ==> From slave : clean MBSS database : " $2
if [ $2 = "yes" ]
then
    ssh -t root@$1 'su - mbssadmin -c "adminClient.sh -C stopGrid"'
    sleep 15
    ssh root@$1 rm -rf /data/mbss/persons/*
    ssh root@$1 rm -rf /data/mbss/latents/*
    sleep 15
    ssh -t root@$1 'su - mbssadmin -c "echo "YES" | resetZKcountAtDCstartUp.sh -allpartitions"'
    ssh -t root@$1 'su - mbssadmin -c "adminClient.sh -C resetCounterAll"'
    ssh -t root@$1 'su - mbssadmin -c "adminClient.sh -C startGrid"'
    echo "***** MBSS ==> From slave : purge done"
fi

echo "*****************************"



