#!/bin/sh

/opt/mbss/tools/adminClient.sh -C stopGrid
sleep 15

rm -rf /data/mbss/persons/*
rm -rf /data/mbss/latents/*
sleep 15

# Restart zookeeper services
/opt/mbss/tools/adminClient.sh -C stopZookeeper
/opt/mbss/tools/adminClient.sh -C startZookeeper
sleep 15

# Restart RabbitMQ services
/opt/mbss/tools/adminClient.sh -C stopRabbitmq
/opt/mbss/tools/adminClient.sh -C startRabbitmq
sleep 15

# Restart AdminDaemon services
/opt/mbss/tools/adminClient.sh -C stopadminDaemon
/opt/mbss/tools/adminClient.sh -C startadminDaemon
sleep 15

# Clear Paging space
swapoff -a
sleep 30
swapon -a

# su - mbssadmin -c "echo "YES" | resetZKcountAtDCstartUp.sh -allpartitions"

/opt/mbss/tools/adminClient.sh -C resetCounterAll
/opt/mbss/tools/adminClient.sh -C startGrid
