#!/bin/sh

MBIS_INTEG_SCRIPTS=/delivery/CleanDB
BCK=10.126.29.76
BCK_RMT1=10.126.29.180
DBM=$BCK
MBSS=$BCK


echo "***** Init DBM *****"
sh $MBIS_INTEG_SCRIPTS/CleanDBM.sh

echo "***** Init MBSS ****"
#sh $MBIS_INTEG_SCRIPTS/CleanMBSS.sh

echo "***** Init REMOTE *****"
ssh -t root@$BCK_RMT1 sh $MBIS_INTEG_SCRIPTS/CleanRemote.sh

echo "***** Restart BackEnd *****"

