#!/bin/sh

runuser -l oracle -c 'sqlplus SYS/Printrak@bisdb/PROD1PDB AS SYSDBA @/tmp/cleanup/CleanMBIS.sql'

