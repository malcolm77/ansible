#!/bin/sh

echo "***** DBM ==> clean MBIS AUTHOR database"
runuser -l bisora -c 'sqlplus SYS/Printrak@bisdb/PROD1PDB AS SYSDBA @/opt/CleanDB/clean_AUTHOR.sql'

